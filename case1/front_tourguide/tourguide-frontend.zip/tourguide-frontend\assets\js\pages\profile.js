/**
 * TAILORA TOUR GUIDE — PROFILE & SETTINGS CONTROLLER
 * Manages tour guide profile information, credentials, and UI settings.
 */

(function () {
  "use strict";

  function init() {
    if (document.body.dataset.page !== "profile") return;

    const user = window.TL.Auth.getCachedUser() || {};

    const nameInput = document.getElementById("profileNameInput");
    const emailInput = document.getElementById("profileEmailInput");
    const rateInput = document.getElementById("profileRateInput");
    const specInput = document.getElementById("profileSpecInput");
    const bioInput = document.getElementById("profileBioInput");

    if (nameInput) nameInput.value = user.name || "Alex Vance";
    if (emailInput) emailInput.value = user.email || "guide@tailora.com";
    if (rateInput) rateInput.value = user.hourly_rate || "45";
    if (specInput) specInput.value = user.specialty || "Historical & Cultural Specialist";
    if (bioInput) bioInput.value = user.bio || "Passionate licensed tour guide with over 8 years of experience showcasing historical monuments, art galleries, and hidden culinary spots in Florence and Kyoto.";

    document.getElementById("profileForm")?.addEventListener("submit", function (e) {
      e.preventDefault();
      const updated = {
        ...user,
        name: nameInput.value.trim(),
        email: emailInput.value.trim(),
        hourly_rate: rateInput.value.trim(),
        specialty: specInput.value.trim(),
        bio: bioInput.value.trim()
      };

      window.TL.Auth.setCachedUser(updated);
      window.TL.showToast("Profile settings updated successfully!", "success");
      setTimeout(() => window.location.reload(), 800);
    });

    document.getElementById("securityForm")?.addEventListener("submit", function (e) {
      e.preventDefault();
      window.TL.showToast("Password updated successfully!", "success");
      document.getElementById("securityForm").reset();
    });
  }

  document.addEventListener("DOMContentLoaded", init);
})();
