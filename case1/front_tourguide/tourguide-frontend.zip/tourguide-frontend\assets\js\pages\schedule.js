/**
 * TAILORA TOUR GUIDE — SCHEDULE PAGE CONTROLLER
 * Visual schedule view for confirmed and upcoming tour itineraries.
 */

(function () {
  "use strict";

  async function loadSchedule() {
    window.TL.showLoading();
    try {
      const res = await window.TL.TourGuideApi.getSchedule();
      const tours = Array.isArray(res.data) ? res.data : Array.isArray(res) ? res : [];
      renderSchedule(tours);
    } catch (err) {
      window.TL.showToast("Failed to load tour schedule: " + err.message, "error");
    } finally {
      window.TL.hideLoading();
    }
  }

  function renderSchedule(tours) {
    const listEl = document.getElementById("scheduleList");
    if (!listEl) return;

    if (tours.length === 0) {
      listEl.innerHTML = `
        <div class="tl-card tl-empty-state">
          <i class="bi bi-calendar-x fs-1 text-teal"></i>
          <h5>No Tours Scheduled</h5>
          <p class="tl-text-secondary">You currently have no confirmed upcoming tours on your schedule.</p>
        </div>`;
      return;
    }

    listEl.innerHTML = tours.map(tour => `
      <div class="tl-card tl-card--hover mb-3 border-start border-4 border-teal">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">
          <div class="d-flex align-items-start gap-3">
            <div class="p-3 rounded-3 bg-teal bg-opacity-10 text-teal fs-3">
              <i class="bi bi-map"></i>
            </div>
            <div>
              <div class="d-flex align-items-center gap-2 mb-1">
                <span class="tl-badge tl-badge--info"><i class="bi bi-clock me-1"></i> ${tour.time}</span>
                <span class="tl-badge tl-badge--success"><i class="bi bi-check-circle me-1"></i> ${tour.status}</span>
              </div>
              <h5 class="text-light mb-1">${tour.title}</h5>
              <div class="tl-metadata">
                <i class="bi bi-person me-1"></i> Traveler: <strong>${tour.traveler}</strong> &bull;
                <i class="bi bi-geo-alt me-1"></i> Meeting Point: <strong>${tour.location}</strong>
              </div>
            </div>
          </div>

          <div class="d-flex align-items-center gap-2 w-100 w-md-auto justify-content-end">
            <a href="messages.html" class="tl-btn tl-btn--outline tl-btn--sm">
              <i class="bi bi-chat-dots me-1"></i> Chat
            </a>
            <button class="tl-btn tl-btn--primary tl-btn--sm view-tour-btn" data-id="${tour.id}">
              <i class="bi bi-info-circle me-1"></i> View Itinerary
            </button>
          </div>
        </div>
      </div>
    `).join("");

    listEl.querySelectorAll(".view-tour-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        window.TL.showToast("Itinerary details ready. You can message the traveler anytime!", "info");
      });
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    if (document.body.dataset.page === "schedule") {
      loadSchedule();
    }
  });
})();
