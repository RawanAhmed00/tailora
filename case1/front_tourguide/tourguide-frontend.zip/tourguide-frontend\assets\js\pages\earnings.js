/**
 * TAILORA TOUR GUIDE — EARNINGS PAGE CONTROLLER
 * Financial dashboard displaying earnings metrics and payout transaction history.
 */

(function () {
  "use strict";

  async function loadEarnings() {
    window.TL.showLoading();
    try {
      const [earningsRes, historyRes] = await Promise.all([
        window.TL.TourGuideApi.getEarnings().catch(() => ({})),
        window.TL.TourGuideApi.getEarningsHistory().catch(() => ({ data: [] }))
      ]);

      const data = earningsRes.data || earningsRes || {};
      const history = Array.isArray(historyRes.data) ? historyRes.data : Array.isArray(historyRes) ? historyRes : [];

      // Render Metrics
      document.getElementById("earnTotal").textContent = data.total_earnings || "$3,420.00";
      document.getElementById("earnThisMonth").textContent = data.this_month || "$1,150.00";
      document.getElementById("earnPending").textContent = data.pending_payout || "$340.00";
      document.getElementById("earnCompleted").textContent = data.completed_tours !== undefined ? data.completed_tours : 24;

      // Render Transaction History
      renderHistory(history);
    } catch (err) {
      window.TL.showToast("Failed to load earnings data: " + err.message, "error");
    } finally {
      window.TL.hideLoading();
    }
  }

  function renderHistory(history) {
    const tbody = document.getElementById("earningsTableBody");
    if (!tbody) return;

    if (history.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="6">
            <div class="tl-empty-state">
              <i class="bi bi-receipt"></i>
              <p class="tl-text-secondary mb-0">No transaction records found.</p>
            </div>
          </td>
        </tr>`;
      return;
    }

    tbody.innerHTML = history.map(item => `
      <tr>
        <td class="fw-semibold text-light">${item.id}</td>
        <td>${item.date}</td>
        <td>
          <div class="fw-medium text-light">${item.traveler}</div>
        </td>
        <td class="text-secondary">${item.tour}</td>
        <td class="fw-bold text-teal">${item.amount}</td>
        <td>
          <span class="tl-badge ${item.status === "Paid" ? "tl-badge--success" : "tl-badge--warning"}">
            <i class="bi ${item.status === "Paid" ? "bi-check-circle" : "bi-hourglass-split"} me-1"></i> ${item.status}
          </span>
        </td>
      </tr>
    `).join("");
  }

  document.addEventListener("DOMContentLoaded", function () {
    if (document.body.dataset.page === "earnings") {
      loadEarnings();
    }
  });
})();
