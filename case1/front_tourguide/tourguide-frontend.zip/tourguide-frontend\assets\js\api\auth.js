/**
 * TAILORA TOUR GUIDE — AUTH MODULE
 * Manages login, logout, session persistence, and authentication guard for protected pages.
 */

(function () {
  "use strict";

  const LOGIN_PAGE = "index.html";
  const DASHBOARD_PAGE = "dashboard.html";

  function setToken(token) {
    return window.TL.Api.setToken(token);
  }

  function getToken() {
    return window.TL.Api.getToken();
  }

  function clearToken() {
    window.TL.Api.clearToken();
  }

  function isAuthenticated() {
    return Boolean(getToken());
  }

  function getCachedUser() {
    const raw = localStorage.getItem(window.TL.Api.config.userKey);
    if (!raw) {
      return {
        id: 5,
        name: "Alex Vance",
        email: "guide@tailora.com",
        role: "Tour Guide",
        specialty: "Historical & Cultural Specialist",
        rating: 4.9,
        avatar: "AV"
      };
    }
    try {
      return JSON.parse(raw);
    } catch {
      return { name: "Tour Guide" };
    }
  }

  function setCachedUser(user) {
    if (user) {
      localStorage.setItem(window.TL.Api.config.userKey, JSON.stringify(user));
    }
  }

  function extractToken(res) {
    if (!res) return null;
    if (res.token) return res.token;
    if (res.access_token) return res.access_token;
    if (res.data && res.data.token) return res.data.token;
    if (res.data && res.data.access_token) return res.data.access_token;
    return null;
  }

  async function login({ email, password }) {
    if (!email || !password) {
      throw new Error("Email and password are required.");
    }

    let response;
    try {
      response = await window.TL.Api.post("/auth/login", { email, password });
      const token = extractToken(response) || "demo_tourguide_bearer_token_123456789";
      setToken(token);
      if (response.data && response.data.user) {
        setCachedUser(response.data.user);
      } else if (response.user) {
        setCachedUser(response.user);
      } else {
        setCachedUser({
          id: 5,
          name: email.split("@")[0].replace(".", " ").toUpperCase(),
          email: email,
          role: "Tour Guide"
        });
      }
      return response;
    } catch (err) {
      // Mock Fallback for local demo testing if API server is not running
      if (err instanceof window.TL.Api.ApiNetworkError || err.status === 404) {
        console.warn("API server unavailable, using Tour Guide demo session.");
        const demoToken = "demo_tourguide_bearer_token_123456789";
        setToken(demoToken);
        setCachedUser({
          id: 5,
          name: "Alex Vance",
          email: email || "guide@tailora.com",
          role: "Verified Tour Guide",
          specialty: "Historical & Culinary Expert",
          rating: 4.9
        });
        return { status: "success", token: demoToken };
      }
      throw err;
    }
  }

  async function logout() {
    try {
      if (getToken()) {
        await window.TL.Api.post("/auth/logout");
      }
    } catch (e) {
      console.warn("Logout request skipped or failed:", e);
    } finally {
      clearToken();
      window.location.replace(LOGIN_PAGE);
    }
  }

  function handle401() {
    clearToken();
    if (!isAuthPage()) {
      window.location.replace(LOGIN_PAGE);
    }
  }

  function isAuthPage() {
    const path = window.location.pathname.toLowerCase();
    return path.endsWith("/index.html") || path.endsWith("/") || path.includes("index.html");
  }

  function guard() {
    const body = document.body;
    const requiresAuth = body.dataset.requiresAuth === "true";
    const guestOnly = body.dataset.guestOnly === "true";

    if (requiresAuth && !isAuthenticated()) {
      window.location.replace(LOGIN_PAGE);
    } else if (guestOnly && isAuthenticated()) {
      window.location.replace(DASHBOARD_PAGE);
    }
  }

  window.TL = window.TL || {};
  window.TL.Auth = {
    login,
    logout,
    getToken,
    setToken,
    clearToken,
    isAuthenticated,
    getCachedUser,
    setCachedUser,
    handle401,
    guard
  };

  document.addEventListener("DOMContentLoaded", guard);
})();
