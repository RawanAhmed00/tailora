/**
 * TAILORA TOUR GUIDE — REVIEWS PAGE CONTROLLER
 * Rating score breakdown and traveler reviews management.
 */

(function () {
  "use strict";

  async function loadReviews() {
    window.TL.showLoading();
    try {
      const [reviewsRes, ratingRes] = await Promise.all([
        window.TL.TourGuideApi.getReviews().catch(() => ({ data: [] })),
        window.TL.TourGuideApi.getRating().catch(() => ({ data: {} }))
      ]);

      const reviews = Array.isArray(reviewsRes.data) ? reviewsRes.data : Array.isArray(reviewsRes) ? reviewsRes : [];
      const rating = ratingRes.data || ratingRes || {};

      // Render Rating Hero
      document.getElementById("avgRatingScore").textContent = rating.overall_rating ? `${rating.overall_rating}` : "4.9";
      document.getElementById("totalReviewsCount").textContent = `${rating.total_reviews || reviews.length || 38} verified traveler reviews`;

      // Render Review List
      renderReviewList(reviews);
    } catch (err) {
      window.TL.showToast("Failed to load reviews: " + err.message, "error");
    } finally {
      window.TL.hideLoading();
    }
  }

  function renderStars(num) {
    let html = "";
    for (let i = 1; i <= 5; i++) {
      if (i <= num) html += '<i class="bi bi-star-fill text-warning me-1"></i>';
      else html += '<i class="bi bi-star text-secondary me-1"></i>';
    }
    return html;
  }

  function renderReviewList(reviews) {
    const list = document.getElementById("reviewsList");
    if (!list) return;

    if (reviews.length === 0) {
      list.innerHTML = `
        <div class="tl-card tl-empty-state">
          <i class="bi bi-star fs-1 text-teal"></i>
          <p class="tl-text-secondary mb-0">No traveler reviews received yet.</p>
        </div>`;
      return;
    }

    list.innerHTML = reviews.map(rev => `
      <div class="tl-card tl-card--hover mb-3">
        <div class="d-flex justify-content-between align-items-start gap-3 mb-3">
          <div class="d-flex align-items-center gap-3">
            <div class="tl-avatar">${rev.avatar || rev.author[0]}</div>
            <div>
              <h6 class="mb-0 text-light">${rev.author}</h6>
              <div class="tl-metadata"><i class="bi bi-check-circle-fill text-teal me-1"></i> ${rev.tour || "Florence Tour"} &bull; ${rev.date}</div>
            </div>
          </div>
          <div>${renderStars(rev.rating)}</div>
        </div>

        <p class="tl-body text-secondary mb-3">${rev.comment}</p>

        <div class="d-flex justify-content-end">
          <button class="tl-btn tl-btn--ghost tl-btn--sm reply-btn" data-author="${rev.author}">
            <i class="bi bi-reply me-1"></i> Send Thank You Note
          </button>
        </div>
      </div>
    `).join("");

    list.querySelectorAll(".reply-btn").forEach(b => {
      b.addEventListener("click", () => {
        window.TL.showToast(`Thank you note sent to ${b.dataset.author}!`, "success");
      });
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    if (document.body.dataset.page === "reviews") {
      loadReviews();
    }
  });
})();
