/**
 * TAILORA TOUR GUIDE — REQUESTS PAGE CONTROLLER
 * Full management of booking requests: filtering, details modal, accept and reject API operations.
 */

(function () {
  "use strict";

  let allRequests = [];
  let currentFilter = "all";

  async function loadRequests() {
    window.TL.showLoading();
    try {
      const res = await window.TL.TourGuideApi.getRequests();
      allRequests = Array.isArray(res.data) ? res.data : Array.isArray(res) ? res : [];
      renderRequests();
    } catch (err) {
      window.TL.showToast("Failed to load requests: " + err.message, "error");
    } finally {
      window.TL.hideLoading();
    }
  }

  function renderRequests() {
    const grid = document.getElementById("requestsGrid");
    if (!grid) return;

    const searchTerm = (document.getElementById("requestsSearchInput")?.value || "").toLowerCase();

    let filtered = allRequests.filter(req => {
      if (currentFilter !== "all" && req.status !== currentFilter) return false;
      if (searchTerm) {
        const text = `${req.traveler_name} ${req.location} ${req.notes || ""}`.toLowerCase();
        if (!text.includes(searchTerm)) return false;
      }
      return true;
    });

    if (filtered.length === 0) {
      grid.innerHTML = `
        <div class="col-12">
          <div class="tl-card tl-empty-state">
            <i class="bi bi-inbox fs-1 text-teal"></i>
            <h5>No Requests Found</h5>
            <p class="tl-text-secondary">No tour guide requests match your current filters.</p>
          </div>
        </div>`;
      return;
    }

    grid.innerHTML = filtered.map(req => {
      const badgeCls = req.status === "accepted" ? "tl-badge--success" : req.status === "rejected" ? "tl-badge--danger" : "tl-badge--warning";
      const statusIcon = req.status === "accepted" ? "bi-check-circle" : req.status === "rejected" ? "bi-x-circle" : "bi-hourglass-split";

      return `
        <div class="col-md-6 col-lg-4">
          <div class="tl-card tl-card--hover tl-card--accent">
            <div class="tl-card__head">
              <div class="d-flex align-items-center gap-3">
                <div class="tl-avatar">${req.traveler_avatar || req.traveler_name[0]}</div>
                <div>
                  <h6 class="mb-0 text-light">${req.traveler_name}</h6>
                  <span class="tl-metadata"><i class="bi bi-people me-1"></i>${req.group_size} Guests</span>
                </div>
              </div>
              <span class="tl-badge ${badgeCls} text-capitalize">
                <i class="bi ${statusIcon}"></i> ${req.status}
              </span>
            </div>

            <div class="mb-3">
              <div class="fw-semibold text-teal mb-1"><i class="bi bi-geo-alt me-1"></i> ${req.location}</div>
              <div class="tl-metadata mb-2">
                <i class="bi bi-calendar-event me-1"></i> ${req.date} &bull; ${req.time || "09:00 AM"} (${req.duration || "4 Hours"})
              </div>
              <p class="tl-body text-secondary small text-truncate-2 mb-0" style="min-height: 40px;">
                ${req.notes || "No additional traveler notes provided."}
              </p>
            </div>

            <div class="pt-3 border-top border-secondary border-opacity-25 d-flex align-items-center justify-content-between">
              <div>
                <span class="tl-label d-block">Fee Offered</span>
                <span class="fs-5 fw-bold text-light">${req.fee || "$180"}</span>
              </div>
              <div class="d-flex gap-1">
                <button class="tl-btn tl-btn--outline tl-btn--sm view-btn" data-id="${req.id}">
                  <i class="bi bi-eye"></i> Details
                </button>
                ${req.status === "pending" ? `
                  <button class="tl-btn tl-btn--success tl-btn--sm accept-btn" data-id="${req.id}">
                    <i class="bi bi-check-lg"></i>
                  </button>
                  <button class="tl-btn tl-btn--danger tl-btn--sm reject-btn" data-id="${req.id}">
                    <i class="bi bi-x-lg"></i>
                  </button>
                ` : ""}
              </div>
            </div>
          </div>
        </div>`;
    }).join("");

    // Event Listeners
    grid.querySelectorAll(".view-btn").forEach(b => b.addEventListener("click", () => openDetailModal(b.dataset.id)));
    grid.querySelectorAll(".accept-btn").forEach(b => b.addEventListener("click", () => executeAction(b.dataset.id, "accept")));
    grid.querySelectorAll(".reject-btn").forEach(b => b.addEventListener("click", () => executeAction(b.dataset.id, "reject")));
  }

  async function openDetailModal(id) {
    window.TL.showLoading();
    try {
      const res = await window.TL.TourGuideApi.getRequest(id);
      const req = res.data || res;
      if (!req) return;

      const modalBody = document.getElementById("requestModalBody");
      const modalFooter = document.getElementById("requestModalFooter");

      if (modalBody) {
        modalBody.innerHTML = `
          <div class="d-flex align-items-center gap-3 mb-4 p-3 rounded-3 bg-body-tertiary border border-secondary border-opacity-25">
            <div class="tl-avatar fs-4" style="width:50px; height:50px;">${req.traveler_avatar || req.traveler_name[0]}</div>
            <div>
              <h5 class="mb-1 text-light">${req.traveler_name}</h5>
              <span class="tl-metadata"><i class="bi bi-envelope me-1"></i> Verified Traveler &bull; ${req.group_size} Guests</span>
            </div>
          </div>

          <div class="row g-3 mb-4">
            <div class="col-6">
              <span class="tl-label">Tour Location</span>
              <div class="fw-semibold text-teal fs-6">${req.location}</div>
            </div>
            <div class="col-6">
              <span class="tl-label">Offered Tour Fee</span>
              <div class="fw-bold text-light fs-5">${req.fee || "$180"}</div>
            </div>
            <div class="col-6">
              <span class="tl-label">Requested Date</span>
              <div class="fw-medium text-light">${req.date}</div>
            </div>
            <div class="col-6">
              <span class="tl-label">Time & Duration</span>
              <div class="fw-medium text-light">${req.time || "09:00 AM"} (${req.duration || "4 Hours"})</div>
            </div>
          </div>

          <div class="mb-3">
            <span class="tl-label mb-1 d-block">Traveler Notes & Special Requests</span>
            <div class="p-3 rounded-3 bg-body-secondary border border-secondary border-opacity-25 text-secondary">
              ${req.notes || "No special requests."}
            </div>
          </div>`;
      }

      if (modalFooter) {
        modalFooter.innerHTML = `
          <button type="button" class="tl-btn tl-btn--ghost" data-bs-dismiss="modal">Close</button>
          <a href="messages.html" class="tl-btn tl-btn--outline"><i class="bi bi-chat-dots me-1"></i> Message Traveler</a>
          ${req.status === "pending" ? `
            <button class="tl-btn tl-btn--danger modal-reject-btn" data-id="${req.id}"><i class="bi bi-x-lg me-1"></i> Reject</button>
            <button class="tl-btn tl-btn--success modal-accept-btn" data-id="${req.id}"><i class="bi bi-check-lg me-1"></i> Accept Request</button>
          ` : ""}`;

        modalFooter.querySelector(".modal-accept-btn")?.addEventListener("click", () => {
          closeModal();
          executeAction(req.id, "accept");
        });
        modalFooter.querySelector(".modal-reject-btn")?.addEventListener("click", () => {
          closeModal();
          executeAction(req.id, "reject");
        });
      }

      const bsModal = new bootstrap.Modal(document.getElementById("requestDetailModal"));
      bsModal.show();
    } catch (err) {
      window.TL.showToast("Failed to fetch request details: " + err.message, "error");
    } finally {
      window.TL.hideLoading();
    }
  }

  function closeModal() {
    const el = document.getElementById("requestDetailModal");
    const instance = bootstrap.Modal.getInstance(el);
    if (instance) instance.hide();
  }

  async function executeAction(id, action) {
    window.TL.showLoading();
    try {
      if (action === "accept") {
        await window.TL.TourGuideApi.acceptRequest(id);
        window.TL.showToast("Request accepted successfully!", "success");
      } else {
        await window.TL.TourGuideApi.rejectRequest(id);
        window.TL.showToast("Request rejected.", "info");
      }
      await loadRequests();
    } catch (err) {
      window.TL.showToast(`Operation failed: ${err.message}`, "error");
    } finally {
      window.TL.hideLoading();
    }
  }

  function init() {
    if (document.body.dataset.page !== "requests") return;

    loadRequests();

    // Filter Buttons
    document.querySelectorAll("[data-filter]").forEach(btn => {
      btn.addEventListener("click", () => {
        document.querySelectorAll("[data-filter]").forEach(b => b.classList.remove("active", "tl-btn--primary"));
        document.querySelectorAll("[data-filter]").forEach(b => b.classList.add("tl-btn--ghost"));
        btn.classList.remove("tl-btn--ghost");
        btn.classList.add("active", "tl-btn--primary");
        currentFilter = btn.dataset.filter;
        renderRequests();
      });
    });

    // Search input
    document.getElementById("requestsSearchInput")?.addEventListener("input", renderRequests);
  }

  document.addEventListener("DOMContentLoaded", init);
})();
