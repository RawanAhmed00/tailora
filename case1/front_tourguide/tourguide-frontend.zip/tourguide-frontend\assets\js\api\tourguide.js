/**
 * TAILORA TOUR GUIDE — TOUR GUIDE API SERVICE
 * Connects frontend to all Tour Guide API endpoints documented:
 * - GET /dashboard
 * - GET /requests, GET /requests/{id}, PATCH /requests/{id}/accept, PATCH /requests/{id}/reject
 * - GET /availabilities, POST /availabilities, PUT /availabilities/{id}, DELETE /availabilities/{id}
 * - GET /tour-guide/schedule
 * - GET /tour-guide/earnings, GET /tour-guide/earnings/history
 * - GET /tour-guide/reviews, GET /tour-guide/rating
 */

(function () {
  "use strict";

  // MOCK STORAGE HELPERS for offline/standalone demo experience
  const MOCK_STORAGE = {
    requestsKey: "tailora_mock_requests",
    availKey: "tailora_mock_availabilities",
    scheduleKey: "tailora_mock_schedule"
  };

  function getStoredRequests() {
    const raw = localStorage.getItem(MOCK_STORAGE.requestsKey);
    if (raw) {
      try { return JSON.parse(raw); } catch {}
    }
    const initial = [
      {
        id: 101,
        traveler_name: "Sophia Martinez",
        traveler_avatar: "SM",
        location: "Florence Historic Center & Uffizi",
        date: "2026-08-16",
        time: "09:30 AM",
        duration: "4 Hours",
        group_size: 2,
        fee: "$180",
        notes: "Interested in Renaissance art history and private wine tasting tips.",
        status: "pending",
        created_at: "2026-08-13T10:15:00Z"
      },
      {
        id: 102,
        traveler_name: "Marcus Vance",
        traveler_avatar: "MV",
        location: "Kyoto Arashiyama & Secret Bamboo Groves",
        date: "2026-08-18",
        time: "02:00 PM",
        duration: "5 Hours",
        group_size: 4,
        fee: "$250",
        notes: "We'd love photography spots and authentic ramen recommendations.",
        status: "pending",
        created_at: "2026-08-12T16:40:00Z"
      },
      {
        id: 103,
        traveler_name: "Emma Watson",
        traveler_avatar: "EW",
        location: "Paris Montmartre Hidden Gems & Food Tour",
        date: "2026-08-14",
        time: "10:00 AM",
        duration: "3.5 Hours",
        group_size: 2,
        fee: "$160",
        notes: "Please include a stop at artisanal patisseries.",
        status: "accepted",
        created_at: "2026-08-11T09:20:00Z"
      },
      {
        id: 104,
        traveler_name: "Liam O'Connor",
        traveler_avatar: "LO",
        location: "Tokyo Shinjuku Nightlife & Street Food",
        date: "2026-08-10",
        time: "07:00 PM",
        duration: "3 Hours",
        group_size: 3,
        fee: "$140",
        notes: "Looking for local Izakaya recommendations.",
        status: "rejected",
        created_at: "2026-08-09T14:10:00Z"
      }
    ];
    localStorage.setItem(MOCK_STORAGE.requestsKey, JSON.stringify(initial));
    return initial;
  }

  function saveRequests(list) {
    localStorage.setItem(MOCK_STORAGE.requestsKey, JSON.stringify(list));
  }

  function getStoredAvailabilities() {
    const raw = localStorage.getItem(MOCK_STORAGE.availKey);
    if (raw) {
      try { return JSON.parse(raw); } catch {}
    }
    const initial = [
      { id: 1, tour_guide_id: 5, day: "Monday", start_time: "09:00 AM", end_time: "05:00 PM", status: "Available", max_bookings: 3 },
      { id: 2, tour_guide_id: 5, day: "Wednesday", start_time: "10:00 AM", end_time: "06:00 PM", status: "Available", max_bookings: 2 },
      { id: 3, tour_guide_id: 5, day: "Friday", start_time: "09:00 AM", end_time: "04:00 PM", status: "Available", max_bookings: 4 },
      { id: 4, tour_guide_id: 5, day: "Saturday", start_time: "08:00 AM", end_time: "02:00 PM", status: "Limited", max_bookings: 1 }
    ];
    localStorage.setItem(MOCK_STORAGE.availKey, JSON.stringify(initial));
    return initial;
  }

  function saveAvailabilities(list) {
    localStorage.setItem(MOCK_STORAGE.availKey, JSON.stringify(list));
  }

  // API METHODS
  const TourGuideApi = {
    // GET /dashboard
    async getDashboard() {
      try {
        return await window.TL.Api.get("/dashboard");
      } catch (err) {
        if (err instanceof window.TL.Api.ApiNetworkError || err.status === 404) {
          const reqs = getStoredRequests();
          const pendingCount = reqs.filter(r => r.status === "pending").length;
          return {
            status: "success",
            data: {
              total_requests: reqs.length,
              pending_requests: pendingCount,
              accepted_requests: reqs.filter(r => r.status === "accepted").length,
              total_earnings: "$2,840.00",
              average_rating: 4.9,
              total_reviews: 38,
              upcoming_tours_today: 2
            }
          };
        }
        throw err;
      }
    },

    // GET /requests
    async getRequests() {
      try {
        return await window.TL.Api.get("/requests");
      } catch (err) {
        if (err instanceof window.TL.Api.ApiNetworkError || err.status === 404) {
          return { status: "success", data: getStoredRequests() };
        }
        throw err;
      }
    },

    // GET /requests/{id}
    async getRequest(id) {
      try {
        return await window.TL.Api.get(`/requests/${id}`);
      } catch (err) {
        if (err instanceof window.TL.Api.ApiNetworkError || err.status === 404) {
          const item = getStoredRequests().find(r => String(r.id) === String(id));
          return { status: "success", data: item || null };
        }
        throw err;
      }
    },

    // PATCH /requests/{id}/accept
    async acceptRequest(id) {
      try {
        return await window.TL.Api.patch(`/requests/${id}/accept`);
      } catch (err) {
        if (err instanceof window.TL.Api.ApiNetworkError || err.status === 404) {
          const list = getStoredRequests();
          const req = list.find(r => String(r.id) === String(id));
          if (req) {
            req.status = "accepted";
            saveRequests(list);
          }
          return { status: "success", message: "Request accepted successfully", data: req };
        }
        throw err;
      }
    },

    // PATCH /requests/{id}/reject
    async rejectRequest(id) {
      try {
        return await window.TL.Api.patch(`/requests/${id}/reject`);
      } catch (err) {
        if (err instanceof window.TL.Api.ApiNetworkError || err.status === 404) {
          const list = getStoredRequests();
          const req = list.find(r => String(r.id) === String(id));
          if (req) {
            req.status = "rejected";
            saveRequests(list);
          }
          return { status: "success", message: "Request rejected successfully", data: req };
        }
        throw err;
      }
    },

    // GET /availabilities
    async getAvailabilities() {
      try {
        return await window.TL.Api.get("/availabilities");
      } catch (err) {
        if (err instanceof window.TL.Api.ApiNetworkError || err.status === 404) {
          return { status: "success", data: getStoredAvailabilities() };
        }
        throw err;
      }
    },

    // POST /availabilities
    async createAvailability(data) {
      try {
        return await window.TL.Api.post("/availabilities", data);
      } catch (err) {
        if (err instanceof window.TL.Api.ApiNetworkError || err.status === 404) {
          const list = getStoredAvailabilities();
          const newItem = {
            id: Date.now(),
            tour_guide_id: 5,
            day: data.day || "Monday",
            start_time: data.start_time || "09:00 AM",
            end_time: data.end_time || "05:00 PM",
            status: data.status || "Available",
            max_bookings: parseInt(data.max_bookings) || 3
          };
          list.push(newItem);
          saveAvailabilities(list);
          return { status: "success", message: "Availability created", data: newItem };
        }
        throw err;
      }
    },

    // PUT /availabilities/{id}
    async updateAvailability(id, data) {
      try {
        return await window.TL.Api.put(`/availabilities/${id}`, data);
      } catch (err) {
        if (err instanceof window.TL.Api.ApiNetworkError || err.status === 404) {
          const list = getStoredAvailabilities();
          const idx = list.findIndex(a => String(a.id) === String(id));
          if (idx !== -1) {
            list[idx] = { ...list[idx], ...data };
            saveAvailabilities(list);
            return { status: "success", message: "Availability updated", data: list[idx] };
          }
          return { status: "error", message: "Record not found" };
        }
        throw err;
      }
    },

    // DELETE /availabilities/{id}
    async deleteAvailability(id) {
      try {
        return await window.TL.Api.delete(`/availabilities/${id}`);
      } catch (err) {
        if (err instanceof window.TL.Api.ApiNetworkError || err.status === 404) {
          let list = getStoredAvailabilities();
          list = list.filter(a => String(a.id) !== String(id));
          saveAvailabilities(list);
          return { success: true, message: "Availability deleted successfully" };
        }
        throw err;
      }
    },

    // GET /tour-guide/schedule
    async getSchedule() {
      try {
        return await window.TL.Api.get("/tour-guide/schedule");
      } catch (err) {
        if (err instanceof window.TL.Api.ApiNetworkError || err.status === 404) {
          return {
            success: true,
            data: [
              {
                id: 301,
                title: "Renaissance Art & Hidden Alleyways",
                traveler: "Sophia Martinez",
                date: "2026-08-16",
                time: "09:30 AM - 01:30 PM",
                location: "Piazza del Duomo, Florence",
                status: "Confirmed"
              },
              {
                id: 302,
                title: "Montmartre Artisanal Bakery Walk",
                traveler: "Emma Watson",
                date: "2026-08-14",
                time: "10:00 AM - 01:30 PM",
                location: "Sacré-Cœur Funicular, Paris",
                status: "Confirmed"
              },
              {
                id: 303,
                title: "Kyoto Bamboo Forest Sunset Photography",
                traveler: "Marcus Vance",
                date: "2026-08-18",
                time: "02:00 PM - 07:00 PM",
                location: "Arashiyama Station, Kyoto",
                status: "Scheduled"
              }
            ]
          };
        }
        throw err;
      }
    },

    // GET /tour-guide/earnings
    async getEarnings() {
      try {
        return await window.TL.Api.get("/tour-guide/earnings");
      } catch (err) {
        if (err instanceof window.TL.Api.ApiNetworkError || err.status === 404) {
          return {
            status: "success",
            data: {
              total_earnings: "$3,420.00",
              this_month: "$1,150.00",
              pending_payout: "$340.00",
              completed_tours: 24
            }
          };
        }
        throw err;
      }
    },

    // GET /tour-guide/earnings/history
    async getEarningsHistory() {
      try {
        return await window.TL.Api.get("/tour-guide/earnings/history");
      } catch (err) {
        if (err instanceof window.TL.Api.ApiNetworkError || err.status === 404) {
          return {
            status: "success",
            data: [
              { id: "PAY-9081", date: "2026-08-10", traveler: "Chloe Bennett", tour: "Kyoto Culinary Journey", amount: "$220.00", status: "Paid" },
              { id: "PAY-9074", date: "2026-08-06", traveler: "Daniel Craig", tour: "Florence Sunset Promenade", amount: "$180.00", status: "Paid" },
              { id: "PAY-9062", date: "2026-08-01", traveler: "Olivia Wilde", tour: "Tokyo Shinjuku Secrets", amount: "$250.00", status: "Paid" },
              { id: "PAY-9055", date: "2026-07-28", traveler: "Ethan Hawke", tour: "Paris Wine & Cheese Tasting", amount: "$190.00", status: "Paid" },
              { id: "PAY-9041", date: "2026-07-20", traveler: "Sophia Martinez", tour: "Uffizi Gallery Deep Dive", amount: "$180.00", status: "Pending" }
            ]
          };
        }
        throw err;
      }
    },

    // GET /tour-guide/reviews
    async getReviews() {
      try {
        return await window.TL.Api.get("/tour-guide/reviews");
      } catch (err) {
        if (err instanceof window.TL.Api.ApiNetworkError || err.status === 404) {
          return {
            status: "success",
            data: [
              {
                id: 501,
                author: "Chloe Bennett",
                avatar: "CB",
                rating: 5,
                date: "2026-08-11",
                tour: "Kyoto Culinary Journey",
                comment: "Alex was incredible! Showed us spots we never would have found on our own. 10/10 recommendation!"
              },
              {
                id: 502,
                author: "Daniel Craig",
                avatar: "DC",
                rating: 5,
                date: "2026-08-07",
                tour: "Florence Sunset Promenade",
                comment: "Extremely knowledgeable about Florence history and super friendly. Highlight of our trip!"
              },
              {
                id: 503,
                author: "Olivia Wilde",
                avatar: "OW",
                rating: 4,
                date: "2026-08-02",
                tour: "Tokyo Shinjuku Secrets",
                comment: "Great experience overall. Very helpful with translations and navigating crowded markets."
              }
            ]
          };
        }
        throw err;
      }
    },

    // GET /tour-guide/rating
    async getRating() {
      try {
        return await window.TL.Api.get("/tour-guide/rating");
      } catch (err) {
        if (err instanceof window.TL.Api.ApiNetworkError || err.status === 404) {
          return {
            status: "success",
            data: {
              overall_rating: 4.9,
              total_reviews: 38,
              breakdown: {
                5: 34,
                4: 3,
                3: 1,
                2: 0,
                1: 0
              }
            }
          };
        }
        throw err;
      }
    }
  };

  window.TL = window.TL || {};
  window.TL.TourGuideApi = TourGuideApi;
})();
