/**
 * TAILORA TOUR GUIDE — CHAT API SERVICE
 * Connects frontend to all Chat API endpoints:
 * - GET /chats
 * - GET /chats/{id}
 * - POST /chats/{id}/messages
 * - PUT /chats/{id}/read
 * - GET /chats/unread-count
 * - DELETE /chats/messages/{id}
 */

(function () {
  "use strict";

  const CHAT_STORAGE_KEY = "tailora_mock_chats";

  function getStoredChats() {
    const raw = localStorage.getItem(CHAT_STORAGE_KEY);
    if (raw) {
      try { return JSON.parse(raw); } catch {}
    }
    const initial = {
      chats: [
        { id: 1, user_id: 5, name: "Sophia Martinez", avatar: "SM", last_message: "Hi Alex, looking forward to our Florence tour!", unread: true, created_at: "2026-08-13T12:00:00Z" },
        { id: 2, user_id: 8, name: "Marcus Vance", avatar: "MV", last_message: "Can we adjust the meeting point for Kyoto?", unread: false, created_at: "2026-08-12T15:30:00Z" },
        { id: 3, user_id: 12, name: "Emma Watson", avatar: "EW", last_message: "Thank you for the bakery recommendations!", unread: false, created_at: "2026-08-11T09:45:00Z" }
      ],
      messages: {
        1: [
          { id: 1001, sender_id: 8, receiver_id: 5, trip_id: 10, message: "Hello Alex, I booked the Florence Renaissance tour for Aug 16!", is_read: true, sender: { id: 8, name: "Sophia Martinez" }, created_at: "2026-08-13T11:50:00Z" },
          { id: 1002, sender_id: 5, receiver_id: 8, trip_id: 10, message: "Hello Sophia! Fantastic, I have designed a great itinerary for us.", is_read: true, sender: { id: 5, name: "Alex Vance" }, created_at: "2026-08-13T11:55:00Z" },
          { id: 1003, sender_id: 8, receiver_id: 5, trip_id: 10, message: "Hi Alex, looking forward to our Florence tour!", is_read: false, sender: { id: 8, name: "Sophia Martinez" }, created_at: "2026-08-13T12:00:00Z" }
        ],
        2: [
          { id: 2001, sender_id: 12, receiver_id: 5, trip_id: null, message: "Hi Alex, is Friday afternoon open for Arashiyama?", is_read: true, sender: { id: 12, name: "Marcus Vance" }, created_at: "2026-08-12T14:20:00Z" },
          { id: 2002, sender_id: 5, receiver_id: 12, trip_id: null, message: "Yes Marcus! Friday at 2:00 PM works great.", is_read: true, sender: { id: 5, name: "Alex Vance" }, created_at: "2026-08-12T14:30:00Z" },
          { id: 2003, sender_id: 12, receiver_id: 5, trip_id: null, message: "Can we adjust the meeting point for Kyoto?", is_read: true, sender: { id: 12, name: "Marcus Vance" }, created_at: "2026-08-12T15:30:00Z" }
        ],
        3: [
          { id: 3001, sender_id: 15, receiver_id: 5, trip_id: 14, message: "Thank you for the bakery recommendations!", is_read: true, sender: { id: 15, name: "Emma Watson" }, created_at: "2026-08-11T09:45:00Z" }
        ]
      }
    };
    localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(initial));
    return initial;
  }

  function saveChats(store) {
    localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(store));
  }

  const ChatApi = {
    // GET /chats
    async getChats() {
      try {
        return await window.TL.Api.get("/chats");
      } catch (err) {
        if (err instanceof window.TL.Api.ApiNetworkError || err.status === 404) {
          const store = getStoredChats();
          return { data: store.chats };
        }
        throw err;
      }
    },

    // GET /chats/{id}
    async getChatMessages(id) {
      try {
        return await window.TL.Api.get(`/chats/${id}`);
      } catch (err) {
        if (err instanceof window.TL.Api.ApiNetworkError || err.status === 404) {
          const store = getStoredChats();
          const msgs = store.messages[id] || [];
          return { data: msgs };
        }
        throw err;
      }
    },

    // POST /chats/{id}/messages
    async sendMessage(id, messageText, tripId = null) {
      try {
        return await window.TL.Api.post(`/chats/${id}/messages`, {
          message: messageText,
          trip_id: tripId ? parseInt(tripId) : null
        });
      } catch (err) {
        if (err instanceof window.TL.Api.ApiNetworkError || err.status === 404) {
          const store = getStoredChats();
          const user = window.TL.Auth.getCachedUser() || { id: 5, name: "Alex Vance" };
          const newMsg = {
            id: Date.now(),
            sender_id: user.id || 5,
            receiver_id: 99,
            trip_id: tripId ? parseInt(tripId) : null,
            message: messageText,
            is_read: true,
            sender: { id: user.id || 5, name: user.name || "Alex Vance" },
            created_at: new Date().toISOString()
          };

          if (!store.messages[id]) store.messages[id] = [];
          store.messages[id].push(newMsg);

          const chatObj = store.chats.find(c => String(c.id) === String(id));
          if (chatObj) {
            chatObj.last_message = messageText;
            chatObj.created_at = new Date().toISOString();
          }

          saveChats(store);
          return { status: "success", data: newMsg };
        }
        throw err;
      }
    },

    // PUT /chats/{id}/read
    async markAsRead(id) {
      try {
        return await window.TL.Api.put(`/chats/${id}/read`);
      } catch (err) {
        if (err instanceof window.TL.Api.ApiNetworkError || err.status === 404) {
          const store = getStoredChats();
          const chatObj = store.chats.find(c => String(c.id) === String(id));
          if (chatObj) chatObj.unread = false;
          if (store.messages[id]) {
            store.messages[id].forEach(m => m.is_read = true);
          }
          saveChats(store);
          return { status: "success", message: "Messages marked as read" };
        }
        throw err;
      }
    },

    // GET /chats/unread-count
    async getUnreadCount() {
      try {
        return await window.TL.Api.get("/chats/unread-count");
      } catch (err) {
        if (err instanceof window.TL.Api.ApiNetworkError || err.status === 404) {
          const store = getStoredChats();
          const count = store.chats.filter(c => c.unread).length;
          return { unread_count: count };
        }
        throw err;
      }
    },

    // DELETE /chats/messages/{id}
    async deleteMessage(messageId, chatId = null) {
      try {
        return await window.TL.Api.delete(`/chats/messages/${messageId}`);
      } catch (err) {
        if (err instanceof window.TL.Api.ApiNetworkError || err.status === 404) {
          const store = getStoredChats();
          if (chatId && store.messages[chatId]) {
            store.messages[chatId] = store.messages[chatId].filter(m => String(m.id) !== String(messageId));
          } else {
            Object.keys(store.messages).forEach(cId => {
              store.messages[cId] = store.messages[cId].filter(m => String(m.id) !== String(messageId));
            });
          }
          saveChats(store);
          return { status: "success", message: "Message deleted" };
        }
        throw err;
      }
    }
  };

  window.TL = window.TL || {};
  window.TL.ChatApi = ChatApi;
})();
