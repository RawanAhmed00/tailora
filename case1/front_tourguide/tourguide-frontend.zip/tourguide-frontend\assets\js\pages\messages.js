/**
 * TAILORA TOUR GUIDE — MESSAGES / CHAT CONTROLLER
 * Implements full Chat API functionality:
 * - GET /chats
 * - GET /chats/{id}
 * - POST /chats/{id}/messages (with optional trip_id)
 * - PUT /chats/{id}/read
 * - GET /chats/unread-count
 * - DELETE /chats/messages/{id}
 */

(function () {
  "use strict";

  let activeChatId = null;
  let chats = [];

  async function loadChatList() {
    try {
      const res = await window.TL.ChatApi.getChats();
      chats = Array.isArray(res.data) ? res.data : Array.isArray(res) ? res : [];
      renderChatSidebar();
      if (!activeChatId && chats.length > 0) {
        selectChat(chats[0].id);
      }
    } catch (err) {
      window.TL.showToast("Failed to load chats: " + err.message, "error");
    }
  }

  function renderChatSidebar() {
    const listContainer = document.getElementById("chatListContainer");
    if (!listContainer) return;

    if (chats.length === 0) {
      listContainer.innerHTML = `
        <div class="tl-empty-state p-4">
          <i class="bi bi-chat-square-dots fs-2 text-teal"></i>
          <p class="tl-text-secondary small mb-0">No active traveler conversations.</p>
        </div>`;
      return;
    }

    listContainer.innerHTML = chats.map(c => `
      <div class="tl-chat-item ${String(c.id) === String(activeChatId) ? "is-active" : ""}" data-id="${c.id}">
        <div class="tl-avatar">${c.avatar || c.name[0]}</div>
        <div class="tl-chat-item__info">
          <div class="tl-chat-item__name">
            <span class="text-truncate">${c.name}</span>
            ${c.unread ? '<span class="tl-chat-item__unread"></span>' : ""}
          </div>
          <div class="tl-chat-item__preview">${c.last_message || "No messages yet"}</div>
        </div>
      </div>
    `).join("");

    listContainer.querySelectorAll(".tl-chat-item").forEach(item => {
      item.addEventListener("click", () => selectChat(item.dataset.id));
    });
  }

  async function selectChat(id) {
    activeChatId = id;
    renderChatSidebar();

    const currentChat = chats.find(c => String(c.id) === String(id));
    const headerTitle = document.getElementById("activeChatHeaderTitle");
    const layout = document.querySelector(".tl-chat-layout");

    if (layout) layout.classList.add("has-active-chat");
    if (headerTitle && currentChat) {
      headerTitle.innerHTML = `
        <div class="d-flex align-items-center gap-3">
          <div class="tl-avatar">${currentChat.avatar || currentChat.name[0]}</div>
          <div>
            <h6 class="mb-0 text-light">${currentChat.name}</h6>
            <span class="tl-metadata text-teal"><i class="bi bi-circle-fill me-1" style="font-size: 8px;"></i> Active Session</span>
          </div>
        </div>`;
    }

    // Mark Chat as Read (PUT /chats/{id}/read)
    try {
      await window.TL.ChatApi.markAsRead(id);
      if (currentChat) currentChat.unread = false;
    } catch {}

    // Load Messages (GET /chats/{id})
    await loadMessages(id);
  }

  async function loadMessages(id) {
    const thread = document.getElementById("chatMessagesThread");
    if (!thread) return;

    thread.innerHTML = '<div class="text-center py-4 text-secondary"><div class="spinner-border spinner-border-sm me-2"></div> Loading messages...</div>';

    try {
      const res = await window.TL.ChatApi.getChatMessages(id);
      const msgs = Array.isArray(res.data) ? res.data : Array.isArray(res) ? res : [];
      renderMessagesThread(msgs);
    } catch (err) {
      thread.innerHTML = `<div class="text-center py-4 text-danger">Failed to load message thread.</div>`;
    }
  }

  function renderMessagesThread(msgs) {
    const thread = document.getElementById("chatMessagesThread");
    if (!thread) return;

    if (msgs.length === 0) {
      thread.innerHTML = `
        <div class="tl-empty-state my-auto">
          <i class="bi bi-chat-text fs-1 text-teal"></i>
          <p class="tl-text-secondary">Start a conversation with the traveler!</p>
        </div>`;
      return;
    }

    const currentUser = window.TL.Auth.getCachedUser() || { id: 5 };

    thread.innerHTML = msgs.map(m => {
      const isSent = m.sender_id === (currentUser.id || 5) || (m.sender && m.sender.name === currentUser.name);
      const bubbleCls = isSent ? "tl-message--sent" : "tl-message--received";
      const timeStr = m.created_at ? new Date(m.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : "Just now";

      return `
        <div class="tl-message-bubble ${bubbleCls}" id="msg-${m.id}">
          <div>${escapeHtml(m.message)}</div>
          ${m.trip_id ? `<div class="mt-1 small opacity-75"><i class="bi bi-paperclip me-1"></i> Trip #${m.trip_id} attached</div>` : ""}
          <div class="tl-message__meta">
            <span>${timeStr}</span>
            ${isSent ? '<i class="bi bi-check2-all text-dark ms-1"></i>' : ""}
            <button class="btn btn-link p-0 text-danger ms-2 delete-msg-btn" data-id="${m.id}" title="Delete Message" style="font-size: 11px; text-decoration: none;">
              <i class="bi bi-trash"></i>
            </button>
          </div>
        </div>`;
    }).join("");

    // Auto scroll to bottom
    thread.scrollTop = thread.scrollHeight;

    // Delete Message Handlers (DELETE /chats/messages/{id})
    thread.querySelectorAll(".delete-msg-btn").forEach(btn => {
      btn.addEventListener("click", async (e) => {
        e.stopPropagation();
        const msgId = btn.dataset.id;
        if (!confirm("Delete this message?")) return;

        try {
          await window.TL.ChatApi.deleteMessage(msgId, activeChatId);
          window.TL.showToast("Message deleted.", "info");
          document.getElementById(`msg-${msgId}`)?.remove();
        } catch (err) {
          window.TL.showToast("Failed to delete message: " + err.message, "error");
        }
      });
    });
  }

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str == null ? "" : String(str);
    return div.innerHTML;
  }

  async function handleSendMessage(e) {
    e.preventDefault();
    if (!activeChatId) return;

    const input = document.getElementById("chatInputText");
    const tripInput = document.getElementById("chatTripIdInput");
    const text = input ? input.value.trim() : "";
    const tripId = tripInput ? tripInput.value.trim() : null;

    if (!text) return;

    input.value = "";

    try {
      await window.TL.ChatApi.sendMessage(activeChatId, text, tripId);
      await loadMessages(activeChatId);
      await loadChatList();
    } catch (err) {
      window.TL.showToast("Failed to send message: " + err.message, "error");
    }
  }

  function init() {
    if (document.body.dataset.page !== "messages") return;

    loadChatList();

    document.getElementById("chatSendForm")?.addEventListener("submit", handleSendMessage);
  }

  document.addEventListener("DOMContentLoaded", init);
})();
