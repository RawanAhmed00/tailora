/**
 * TAILORA TOUR GUIDE — DASHBOARD PAGE CONTROLLER
 * Loads overview metrics, recent booking requests, and schedule overview.
 */

(function () {
  "use strict";

  async function loadDashboard() {
    window.TL.showLoading();

    try {
      const [dashRes, requestsRes, scheduleRes] = await Promise.all([
        window.TL.TourGuideApi.getDashboard().catch(() => ({})),
        window.TL.TourGuideApi.getRequests().catch(() => ({ data: [] })),
        window.TL.TourGuideApi.getSchedule().catch(() => ({ data: [] }))
      ]);

      const dashData = dashRes.data || dashRes || {};
      const requests = Array.isArray(requestsRes.data) ? requestsRes.data : Array.isArray(requestsRes) ? requestsRes : [];
      const schedule = Array.isArray(scheduleRes.data) ? scheduleRes.data : Array.isArray(scheduleRes) ? scheduleRes : [];

      // Render KPI cards
      const totalReqEl = document.getElementById("kpiTotalRequests");
      const pendingReqEl = document.getElementById("kpiPendingRequests");
      const earningsEl = document.getElementById("kpiTotalEarnings");
      const ratingEl = document.getElementById("kpiAverageRating");

      if (totalReqEl) totalReqEl.textContent = dashData.total_requests || requests.length || "0";
      if (pendingReqEl) pendingReqEl.textContent = dashData.pending_requests !== undefined ? dashData.pending_requests : requests.filter(r => r.status === "pending").length;
      if (earningsEl) earningsEl.textContent = dashData.total_earnings || "$2,840.00";
      if (ratingEl) ratingEl.textContent = dashData.average_rating ? `${dashData.average_rating} ★` : "4.9 ★";

      // Render Pending Requests Table
      renderPendingRequests(requests);

      // Render Today's Schedule Timeline
      renderScheduleSnippet(schedule);

    } catch (err) {
      window.TL.showToast("Failed to load dashboard data: " + err.message, "error");
    } finally {
      window.TL.hideLoading();
    }
  }

  function renderPendingRequests(requests) {
    const tbody = document.getElementById("pendingRequestsTableBody");
    if (!tbody) return;

    const pending = requests.filter(r => r.status === "pending");

    if (pending.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="6">
            <div class="tl-empty-state">
              <i class="bi bi-check2-circle"></i>
              <h5>No Pending Requests</h5>
              <p class="tl-text-secondary">You have responded to all tour guide booking requests!</p>
            </div>
          </td>
        </tr>`;
      return;
    }

    tbody.innerHTML = pending.map(req => `
      <tr>
        <td>
          <div class="d-flex align-items-center gap-3">
            <div class="tl-avatar">${req.traveler_avatar || req.traveler_name[0]}</div>
            <div>
              <div class="fw-semibold text-light">${req.traveler_name}</div>
              <div class="tl-metadata"><i class="bi bi-people me-1"></i> ${req.group_size} Guests</div>
            </div>
          </div>
        </td>
        <td>
          <div class="fw-medium">${req.location}</div>
          <div class="tl-metadata"><i class="bi bi-clock me-1"></i> ${req.duration || "4 Hours"}</div>
        </td>
        <td>
          <div class="fw-semibold text-light">${req.date}</div>
          <div class="tl-metadata">${req.time || "09:00 AM"}</div>
        </td>
        <td class="fw-bold text-teal">${req.fee || "$180"}</td>
        <td>
          <span class="tl-badge tl-badge--warning"><i class="bi bi-hourglass-split"></i> Pending</span>
        </td>
        <td class="text-end">
          <button class="tl-btn tl-btn--success tl-btn--xs me-1 accept-btn" data-id="${req.id}">
            <i class="bi bi-check-lg"></i> Accept
          </button>
          <button class="tl-btn tl-btn--danger tl-btn--xs reject-btn" data-id="${req.id}">
            <i class="bi bi-x-lg"></i> Reject
          </button>
        </td>
      </tr>
    `).join("");

    // Wire Accept & Reject buttons
    tbody.querySelectorAll(".accept-btn").forEach(btn => {
      btn.addEventListener("click", () => handleAction(btn.dataset.id, "accept"));
    });
    tbody.querySelectorAll(".reject-btn").forEach(btn => {
      btn.addEventListener("click", () => handleAction(btn.dataset.id, "reject"));
    });
  }

  async function handleAction(id, action) {
    window.TL.showLoading();
    try {
      if (action === "accept") {
        await window.TL.TourGuideApi.acceptRequest(id);
        window.TL.showToast(`Request #${id} accepted successfully!`, "success");
      } else {
        await window.TL.TourGuideApi.rejectRequest(id);
        window.TL.showToast(`Request #${id} rejected.`, "info");
      }
      await loadDashboard();
    } catch (err) {
      window.TL.showToast(`Error updating request: ${err.message}`, "error");
    } finally {
      window.TL.hideLoading();
    }
  }

  function renderScheduleSnippet(schedule) {
    const container = document.getElementById("todayScheduleContainer");
    if (!container) return;

    if (!schedule || schedule.length === 0) {
      container.innerHTML = `
        <div class="tl-empty-state">
          <i class="bi bi-calendar-event"></i>
          <p class="tl-text-secondary mb-0">No tours scheduled for today.</p>
        </div>`;
      return;
    }

    container.innerHTML = schedule.map(tour => `
      <div class="p-3 mb-2 rounded-3 border border-secondary border-opacity-25 bg-body-tertiary d-flex align-items-center justify-content-between gap-3">
        <div class="d-flex align-items-center gap-3">
          <div class="p-2 rounded-3 bg-primary bg-opacity-10 text-primary fs-4">
            <i class="bi bi-compass"></i>
          </div>
          <div>
            <div class="fw-semibold text-light">${tour.title}</div>
            <div class="tl-metadata">
              <i class="bi bi-person me-1"></i> Traveler: ${tour.traveler} &bull; <i class="bi bi-geo-alt me-1"></i> ${tour.location}
            </div>
          </div>
        </div>
        <div class="text-end">
          <span class="tl-badge tl-badge--info"><i class="bi bi-clock me-1"></i> ${tour.time}</span>
        </div>
      </div>
    `).join("");
  }

  document.addEventListener("DOMContentLoaded", function () {
    if (document.body.dataset.page === "dashboard") {
      loadDashboard();
    }
  });
})();
